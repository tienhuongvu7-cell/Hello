# 🛠️ Buildly – AI-Powered Website Builder

**Buildly** is an AI-driven website builder that enables users to **generate, preview, and download full-stack web projects directly in the browser** using WebContainers. Simply describe what you want to build — from **personal portfolios** to **to-do apps** — and let Buildly handle the rest!

***

## 🧰 Tech Stack

- **Frontend:** Next.js 15 (App Router) + TypeScript + TailwindCSS
- **In-Browser Dev Environment:** [@webcontainer/api](https://www.npmjs.com/package/@webcontainer/api)
- **Authentication \& Sessions:** Clerk
- **Database:** Prisma + PostgreSQL
- **API Requests:** Axios
- **File Downloads:** JSZip + FileSaver.js

***

## ⚙️ Setup \& Installation

1. **Clone the repository:**

```bash
git clone <your-repo-url>
cd buildly
```

2. **Install dependencies:**

```bash
npm install
```

3. **Configure environment variables** in the `.env` file:

```env
GEMINI_API_KEY=""
DATABASE_URL=""
NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY=""
CLERK_SECRET_KEY=""
CLERK_WEBHOOK_SECRET=""
```

4. **Expose your local app (for Clerk and other integrations) using Cloudflared**

```bash
cloudflared tunnel --url http://localhost:3000
```


***

## 🚀 Features

- **AI-Powered Project Generation:** Generate full-stack web apps from natural language prompts.
- **Live Preview:** Instantly view your project running in the browser.
- **Download Projects:** Export your generated app as a ZIP file.
- **User Authentication:** Secure sign-in via Clerk.
- **Persistent Projects:** Save and manage projects with PostgreSQL.

***

## 📝 Usage

1. Launch the app locally:

```bash
npm run dev
```

2. Sign in with your google account.
3. Enter a prompt describing the app you want to build.
4. Preview and download your generated project.

***

## 📂 Contributing

Contributions are welcome! Please open an issue or submit a pull request to help improve Buildly.

***

## ⚡ Notes

- Ensure your **environment variables** are correctly set before running the app.
- Cloudflared is required for webhook functionality during local development.

***

