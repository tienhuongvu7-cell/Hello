-- AlterTable
ALTER TABLE "Project" ADD COLUMN     "aiReply" TEXT NOT NULL DEFAULT '';
